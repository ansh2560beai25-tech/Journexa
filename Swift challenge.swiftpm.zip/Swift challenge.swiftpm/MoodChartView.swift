import SwiftUI
import Charts

struct MoodChartView: View {
    
    @EnvironmentObject var moodStore: MoodStore
    
    var body: some View {
        
        VStack {
            
            Text("Weekly Mood Trend")
                .font(.headline)
            
            Chart {
                ForEach(Array(moodStore.weeklyScores.enumerated()), id: \.offset) { index, score in
                    
                    LineMark(
                        x: .value("Day", index + 1),
                        y: .value("Mood", score)
                    )
                    .interpolationMethod(.catmullRom)
                    
                    PointMark(
                        x: .value("Day", index + 1),
                        y: .value("Mood", score)
                    )
                }
            }
            .frame(height: 250)
        }
        .padding()
    }
}
