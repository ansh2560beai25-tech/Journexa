import SwiftUI

@main
struct JournexaApp: App {
    
    @StateObject private var moodStore = MoodStore()
    @StateObject private var userProfile = UserProfile()
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(moodStore)
                .environmentObject(userProfile)
        }
    }
}
