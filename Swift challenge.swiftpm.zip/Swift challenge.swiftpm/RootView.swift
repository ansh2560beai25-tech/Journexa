import SwiftUI

struct RootView: View {
    
    @EnvironmentObject var userProfile: UserProfile
    
    var body: some View {
        if userProfile.isOnboarded {
            ReflectionView()
        } else {
            OnboardingView()
        }
    }
}
