import SwiftUI

struct OnboardingView: View {
    
    @EnvironmentObject var userProfile: UserProfile
    
    var body: some View {
        
        ZStack {
            
            LinearGradient(colors: [.purple, .blue],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
            .ignoresSafeArea()
            
            VStack(spacing: 20) {
                
                Text("Welcome to Journexa")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                
                Group {
                    TextField("Your Name", text: $userProfile.name)
                    TextField("Favorite Activity", text: $userProfile.favoriteActivity)
                    TextField("Favorite Music", text: $userProfile.favoriteMusic)
                    TextField("Relaxation Method", text: $userProfile.relaxationMethod)
                }
                .textFieldStyle(.roundedBorder)
                
                Button("Start Journey") {
                    userProfile.isOnboarded = true
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.white)
                .cornerRadius(15)
            }
            .padding()
        }
    }
}
