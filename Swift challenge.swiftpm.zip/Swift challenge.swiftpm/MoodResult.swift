struct MoodResult {
    let score: Int
    let level: MoodLevel
}

enum MoodLevel {
    case low
    case neutral
    case high
}
