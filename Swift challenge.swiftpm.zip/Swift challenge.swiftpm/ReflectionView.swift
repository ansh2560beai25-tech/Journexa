import SwiftUI

struct ReflectionView: View {
    
    @State private var journalText = ""
    @State private var path = NavigationPath()

    enum Route: Hashable {
        case analysis(String)
    }
    
    var body: some View {
        NavigationStack(path: $path) {
            VStack(spacing: 20) {
                
                Text("Reflect on Your Day")
                    .font(.title)
                    .bold()
                
                TextEditor(text: $journalText)
                    .frame(height: 180)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray))
                
                Button {
                    let text = journalText
                    path.append(Route.analysis(text))
                } label: {
                    Text("Analyze Mood")
                        .frame(maxWidth: .infinity)
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(12)
                
                MoodChartView()
                
                Spacer()
            }
            .padding()
            .navigationDestination(for: Route.self) { route in
                switch route {
                case .analysis(let text):
                    AnalysisView(journalText: text)
                }
            }
        }
    }
}
#Preview {
    ReflectionView()
}

